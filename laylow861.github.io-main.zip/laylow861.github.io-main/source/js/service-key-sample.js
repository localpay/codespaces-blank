// 공공데이터 포털 - API Service Key(공공데이터포털 마이페이지에서 Decoding 된 인증키)
var apiServiceKey = "[공공데이터포털 API KEY]";

// Kakao 지도 API - App Key (javascript 키)
var kakaoMapKey = "카카오맵 API javascript KEY"

// 사용처지역코드:
// 특정 광역시/도 또는 시/군/구를 제한하여 검색서비스를 제공하고 싶을 경우, 해당 변수에 법정동 코드의 앞 5자리 입력 (지역별 코드는 `사용처지역코드.xlsx` 참고)
var usageRgnCd = "";